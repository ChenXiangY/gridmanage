import React from 'react'
export default class SearchBar extends React.Component{

    render() {
        return (
            <div>

            </div>
        );
    }
}